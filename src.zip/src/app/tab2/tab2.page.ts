import { Component } from '@angular/core';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page {

  // Aqui listamos los datos para filtar
  allContacts = [
    { title: 'Section A', contacts: ['A1', 'A2', 'A3'] },
    { title: 'Section B', contacts: ['B1', 'B2', 'B3'] }
  ];

  // aqui ya filtramos que mostraremos en la interface
  filteredContacts = [...this.allContacts];

  constructor() {}

  // Método para filtrar segun lo que indicamos en el buscador 
  filterContacts(event: any) {
    const searchTerm = event.target.value.toLowerCase(); //aqui obtenemos la busqueda 
    this.filteredContacts = this.allContacts.map(section => {
      return {
        title: section.title,
        contacts: section.contacts.filter(contact => contact.toLowerCase().includes(searchTerm))
      };
    }).filter(section => section.contacts.length > 0); //FILTRA SI EL BUSCADOR NO ENCUENTRA LO QUE ESCRIBIMOS EN EL 
  }

}
