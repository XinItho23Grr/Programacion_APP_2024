import { Component, OnInit } from '@angular/core';
import { NavController, AlertController } from '@ionic/angular';

@Component({
  selector: 'app-registro',
  templateUrl: './registro.page.html',
  styleUrls: ['./registro.page.scss'],
})
export class RegistroPage implements OnInit {

  constructor(private alertController: AlertController, private navController: NavController) { }

  ngOnInit() {
    // Inicialización si es necesaria
  }

  async registro() {
    // Aquí manejo el proceso del registro

    // Luego muestra la alerta
    const alert = await this.alertController.create({
      header: 'Éxito',
      message: 'Registro realizado correctamente.',
      buttons: ['OK']
    });

    await alert.present();

    // Redirige a la página del login para que la alerta sea cerrada
    await alert.onDidDismiss();
    this.navController.navigateForward('/comienzo');
  }
}