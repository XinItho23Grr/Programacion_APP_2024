import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { Iasignatura, IAlumno } from 'src/interfaces/IAsignatura';
import { ApicrudService } from '../services/apicrud.service';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-detalle-alumno',
  templateUrl: './detalle-alumno.page.html',
  styleUrls: ['./detalle-alumno.page.scss'],
})
export class DetalleAlumnoPage implements OnInit {


  unAsignatura: any;

  usuarios= {
    username: '',
    email: '' 
  }

  id:any;
  qrdata:string;
  nombre: any;

  asignatura={
    id: "",
    nombre: "",
    profesor: "",
    horario: ""
  }

  constructor(
    private activated: ActivatedRoute,
    private router: Router,
    private apicrud: ApicrudService,
    private alertcontroller: AlertController) {
      this.activated.queryParams.subscribe(params=>{
        this.unAsignatura = JSON.parse(params['asignatura'])
      })
      this.qrdata='';
      this.nombre= sessionStorage.getItem('username');
     }

  ngOnInit() {
    this.id = this.unAsignatura.id;
    this.asignatura=this.unAsignatura;
  }

  regresar(){
    this.router.navigate(['/tabs/tabs2']);
  }

  actualizarAsignatura(Observable:Iasignatura){
    this.router.navigate(['/actualizar', this.asignatura.id],
    {queryParams:{asignatura:JSON.stringify(Observable)}})
  }

  generarQr(){
    this.qrdata='';
    this.qrdata = this.unAsignatura.rut + this.unAsignatura.nombre + this.unAsignatura.apellido + this.nombre;
    console.log(this.qrdata);
  }


  async consultaElimina(){
    const alert = await this.alertcontroller.create({
      header: 'Desea Eliminar?',
      message: 'Necesita eliminar la asignatura?',
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          handler: () => {
            this.router.navigate(['/tabs/tab1']);
          },
        },
        {
          text: 'OK',
          role: 'confirm',
          handler: () => {
            this.eliminar();
          },
        },
      ],
    });

    await alert.present();
  }

  eliminar(){
    this.apicrud.deleteAsignatura(this.asignatura).subscribe();
    this.mensaje();
  }
  async mensaje(){
    const alert = await this.alertcontroller.create({
      header: 'Alumno Eliminado!',
      message: 'Sus Datos han sido Eliminado',
      buttons: [
        {
          text: 'OK',
          role: 'confirm',
          handler: () => {
            this.router.navigate(['/tabs/tab1']);
          },
        },
      ],
    });

    await alert.present();

  }

  async mostrarMensaje(){
    const alerta = await this.alertcontroller.create({
      header:'Creando Palabra',
      message: 'Su QR ha sido Almacenado',
      buttons: ['Ok']
    })
    alerta.present();
  }

}
