import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { IAlumno } from 'src/interfaces/IAlumnos';

@Component({
  selector: 'app-detalle-alumno',
  templateUrl: './detalle-alumno.page.html',
  styleUrls: ['./detalle-alumno.page.scss'],
})
export class DetalleAlumnoPage implements OnInit {


  unAlumno: any;

  alumno={
      id: "",
      nombre: "",
      apellido: "",
      rut: "",
      email: "",
      password: ""
  }

  constructor(
    private activated: ActivatedRoute,
    private router: Router) {
      this.activated.queryParams.subscribe(params=>{
        this.unAlumno = JSON.parse(params['alumno'])
      })
     }

  ngOnInit() {
    this.alumno=this.unAlumno;
  }

  regresar(){
    this.router.navigate(['/tabs/tabs']);
  }

  actualizarAlumno(Observable:IAlumno){
    this.router.navigate(['/actualizar', this.alumno.id],
    {queryParams:{alumno:JSON.stringify(Observable)}})
  }

}
