import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { IAlumno } from 'src/interfaces/IAlumnos';
import { ApicrudService } from '../services/apicrud.service';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-detalle-alumno',
  templateUrl: './detalle-alumno.page.html',
  styleUrls: ['./detalle-alumno.page.scss'],
})
export class DetalleAlumnoPage implements OnInit {


  unAlumno: any;

  alumno={
      id: "",
      nombre: "",
      apellido: "",
      rut: "",
      email: "",
      password: ""
  }

  constructor(
    private activated: ActivatedRoute,
    private router: Router,
    private apicrud: ApicrudService,
    private alertcontroller: AlertController) {
      this.activated.queryParams.subscribe(params=>{
        this.unAlumno = JSON.parse(params['alumno'])
      })
     }

  ngOnInit() {
    this.alumno=this.unAlumno;
  }

  regresar(){
    this.router.navigate(['/tabs/tabs']);
  }

  actualizarAlumno(Observable:IAlumno){
    this.router.navigate(['/actualizar', this.alumno.id],
    {queryParams:{alumno:JSON.stringify(Observable)}})
  }

  elimina(){
    this.apicrud.deleteAlumno(this.alumno).subscribe();
    this.mensaje();
  }
  async mensaje(){
    const alert = await this.alertcontroller.create({
      header: 'Alumno Eliminado!',
      message: 'Sus Datos han sido Eliminado',
      buttons: [
        {
          text: 'OK',
          role: 'confirm',
          handler: () => {
            this.router.navigate(['/tabs/tab1']);
          },
        },
      ],
    });

    await alert.present();

  }

}
