import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { IAlumnos, IAlumno } from 'src/interfaces/IAlumnos';

@Injectable({
  providedIn: 'root'
})
export class ApicrudService {

  constructor(private httpclient: HttpClient) { }

  getAlumnos():Observable<IAlumnos[]>{
    return this.httpclient.get<IAlumnos[]>(`${environment.apiUrl}/alumnos`);
  }

  postAlumno(newAlumno: IAlumno):Observable<IAlumno>{
    return this.httpclient.post<IAlumno>(`${environment.apiUrl}/alumnos`,newAlumno);
  }

  putAlumnos(alumno:any):Observable<IAlumnos>{
    return this.httpclient.put<IAlumnos>(`${environment.apiUrl}/alumnos/${alumno.id}`,alumno);

  }
}
