import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { IAsignaturas, Iasignatura, IAlumno } from 'src/interfaces/IAsignatura';

@Injectable({
  providedIn: 'root'
})
export class ApicrudService {

  constructor(private httpclient: HttpClient) { }

  getAsignatura():Observable<IAsignaturas[]>{
    return this.httpclient.get<IAsignaturas[]>(`${environment.apiUrl}/asignatura`);
  }

  postAsignatura(newAsignatura: Iasignatura):Observable<Iasignatura>{
    return this.httpclient.post<Iasignatura>(`${environment.apiUrl}/asignaturas`,newAsignatura);
  }

  putAsignatura(asignatura:any):Observable<IAsignaturas>{
    return this.httpclient.put<IAsignaturas>(`${environment.apiUrl}/asignaturas/${asignatura.id}`,asignatura);

  }

  deleteAsignatura(asignatura:any):Observable<IAsignaturas>{
    return this.httpclient.delete<IAsignaturas>(`${environment.apiUrl}/asignaturas/${asignatura.id}`);
  }

  getAlumnos(): Observable<IAlumno[]> {
  return this.httpclient.get<IAlumno[]>(`${environment.apiUrl}/usuarios`);
  }
}
