import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { FormBuilder,  } from '@angular/forms';

@Component({
  selector: 'app-comienzo',
  templateUrl: './comienzo.page.html',
  styleUrls: ['./comienzo.page.scss'],
})
export class ComienzoPage implements OnInit {

  constructor( private navController: NavController) { }

  ngOnInit() {
  }

  login(){
    // redirigir a la pagina de inicio
    this.navController.navigateForward('/tabs/tab1')
    
  }

  goToRegistro() {
    // Redirigir a la página de registro
    this.navController.navigateForward('/registro');
  }
  
  openUrl(url: string) {
    window.open(url, '_blank');
  }
}
