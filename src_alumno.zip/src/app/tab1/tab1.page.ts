import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApicrudService } from '../services/apicrud.service';
import { MenuController } from '@ionic/angular';
import { Autoplay } from 'swiper';
import SwiperCore, { SwiperModule } from 'swiper/types';


SwiperCore.use([Autoplay]);

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page implements OnInit {
  banners: string[] = [
    "assets/img/escuela1.png", 
    "assets/img/escuela2.png",
    "assets/img/escuela3.png",
    "assets/img/escuela4.png",
    "assets/img/escuela5.jpg",
    "assets/img/escuela6.jpg"
  ];

  slideOpts: any = { // Cambia el tipo a any
    initialSlide: 1,
    speed: 400,
    loop: true,
    autoplay: {
      delay: 4000,
      disableOnInteraction: false,
    },
  };

  postsos: any[] = [];  
  usuario: any;

  constructor(
    private router: Router, 
    private apidato: ApicrudService, 
    private menucontroller: MenuController
  ) {}

  ngOnInit(): void {
    this.usuario = sessionStorage.getItem('username');
    console.log(this.usuario);
  }

  mostrarMenu() {
    this.menucontroller.enable(true);
    this.menucontroller.open('first');
  }
}
