import { Component, OnInit } from '@angular/core';
import { NavController, AlertController } from '@ionic/angular';
import { IAlumno } from 'src/interfaces/IAlumnos';
import { ApicrudService } from '../services/apicrud.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registro',
  templateUrl: './registro.page.html',
  styleUrls: ['./registro.page.scss'],
})
export class RegistroPage implements OnInit {


  alumno:IAlumno={
    nombre:"",
    apellido:"",
    rut:"",
    email:"",
    password:"",
  }

  constructor(private alertController: AlertController, private navController: NavController, 
              private apicrud: ApicrudService, private router:Router) { }

  ngOnInit() {
    // Inicialización si es necesaria
  }


  crearAlumno(){
    this.apicrud.postAlumno(this.alumno).subscribe();
    this.mensaje();
    this.limpiar();
    this.router.navigate(['/tabs/tab2']);
  }

  async mensaje(){
      const alert = await this.alertController.create({
        header: 'Alumno',
        message: 'Alumno Registrado!',
        buttons: ['OK'],
      });
  
      await alert.present();
    }

    limpiar(){

    }

  }

