import { Component, OnInit } from '@angular/core';
import { NavController, AlertController } from '@ionic/angular';
import { Iasignatura } from 'src/interfaces/IAsignatura';
import { ApicrudService } from '../services/apicrud.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registro',
  templateUrl: './registro.page.html',
  styleUrls: ['./registro.page.scss'],
})
export class RegistroPage implements OnInit {


  asignatura:Iasignatura={
    nombre: "",
    profesor:"",
    horario:"",
 }

  constructor(private alertController: AlertController, private navController: NavController, 
              private apicrud: ApicrudService, private router:Router) { }

  ngOnInit() {
    // Inicialización si es necesaria
  }


  crearAsignatura(){
    this.apicrud.postAsignatura(this.asignatura).subscribe();
    this.mensaje();
    this.limpiar();
    this.router.navigate(['/tabs/tab2']);
  }

  async mensaje(){
      const alert = await this.alertController.create({
        header: 'Asignatura',
        message: 'asignatura Registrado!',
        buttons: ['OK'],
      });
  
      await alert.present();
    }

    limpiar(){

    }

  }

