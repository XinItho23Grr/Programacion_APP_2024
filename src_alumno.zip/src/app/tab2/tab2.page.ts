import { Component, OnInit } from '@angular/core';
import { ApidatosService } from '../services/apidatos.service';
import { ApicrudService } from '../services/apicrud.service';
import { IAlumnos } from 'src/interfaces/IAlumnos';
import { Router } from '@angular/router';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page implements OnInit  {

  constructor( private apidatos: ApidatosService,
              private apicrud: ApicrudService,
              private router: Router) {}

  alumno: IAlumnos[]=[];


  ngOnInit(){
    this.apicrud.getAlumnos().subscribe(data => {
      this.alumno = data;
    
    })
  }
  buscarAlumno(Observable: IAlumnos){
    this.router.navigate(['/detalle-alumno'],
      {queryParams:{alumno: JSON.stringify(Observable)}})
  }

  crearAlumno(){
    this.router.navigate(['/registro']);
  }
}



  

