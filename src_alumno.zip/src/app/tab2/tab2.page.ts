import { Component } from '@angular/core';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page {

  // Lista de contactos con sus fechas
  allContacts = [
    { title: 'Matemática', fecha: '2024-08-12' },
    { title: 'Matemática', fecha: '2024-08-13' },
    { title: 'Ingles', fecha: '2024-08-12' },
    { title: 'Ingles', fecha: '2024-08-13' },
    { title: 'Programación Móvil', fecha: '2024-08-12' },
    { title: 'Programación Móvil', fecha: '2024-08-13' },
    { title: 'Arquitectura', fecha: '2024-08-12' },
    { title: 'Arquitectura', fecha: '2024-08-13' }
  ];

  // Contactos que filtranmos se mostrarán
  filteredContacts = [...this.allContacts];

  // Variables para los filtros
  searchTerm: string = '';  // Almacenar el texto del buscador
  selectedDate: string = '';  // Almacenar la fecha seleccionada

  constructor() {}

  // Método para filtrar según el texto ingresado en el buscador
  filterContacts(event: any) {
    this.searchTerm = event.target.value.toLowerCase();  // Guardamos el término de búsqueda
    this.applyFilters();  // Aplicamos los filtros
  }

  // Método para filtrar por la fecha seleccionada en el calendario
  filterByDate(event: any) {
    this.selectedDate = new Date(event.detail.value).toISOString().split('T')[0];  // Guardamos la fecha seleccionada
    this.applyFilters();  // Aplicamos los filtros
  }

  // Método combinado para aplicar ambos filtros
  applyFilters() {
    this.filteredContacts = this.allContacts.filter(contact => {
      const matchesTerm = contact.title.toLowerCase().includes(this.searchTerm);  // Coincide con el término de búsqueda
      const matchesDate = this.selectedDate ? contact.fecha === this.selectedDate : true;  // Coincide con la fecha o no hay fecha seleccionada
      return matchesTerm && matchesDate;  // Solo mostrar si ambos filtros coinciden
    });
  }
}