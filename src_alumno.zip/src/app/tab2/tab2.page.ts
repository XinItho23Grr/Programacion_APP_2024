import { Component } from '@angular/core';
import { ApidatosService } from '../services/apidatos.service';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page {

  allContacts = [
    { title: 'Matemáticas', fecha: '2024-08-12', profesor: 'Prof. Juan Pérez' },
    { title: 'Matemáticas', fecha: '2024-08-13', profesor: 'Prof. Juan Pérez' },
    { title: 'Inglés', fecha: '2024-08-12', profesor: 'Prof. María González' },
    { title: 'Inglés', fecha: '2024-08-13', profesor: 'Prof. María González' },
    { title: 'Programación Móvil', fecha: '2024-08-12', profesor: 'Prof. Carlos Ramírez' },
    { title: 'Programación Móvil', fecha: '2024-08-13', profesor: 'Prof. Carlos Ramírez' },
    { title: 'Arquitectura de Software', fecha: '2024-08-12', profesor: 'Prof. Laura Torres' },
    { title: 'Arquitectura de Software', fecha: '2024-08-13', profesor: 'Prof. Laura Torres' }
  ];

  filteredContacts = [...this.allContacts];

  searchTerm: string = '';
  selectedDate: string = '';

  Users:any[]=[];

  constructor( private apidatos: ApidatosService) {}


//invocamos metodo creado en el servicio
  cargarUsers(){
    this.apidatos.getUsers().subscribe(resp=>{
      console.log(resp);
    })
    this.apidatos.getUsers().subscribe(
      datos => this.Users = datos,      //enviamos a un arreglo la info
    )
  
  }
  
  filterContacts(event: any) {
    this.searchTerm = event.target.value.toLowerCase();
    this.applyFilters();
  }

  onDateChange(event: any) {
    this.selectedDate = new Date(event.detail.value).toISOString().split('T')[0];
    this.applyFilters();
  }

  applyFilters() {
    this.filteredContacts = this.allContacts.filter(contact => {
      const matchesTerm = contact.title.toLowerCase().includes(this.searchTerm);
      const matchesDate = this.selectedDate ? contact.fecha === this.selectedDate : true;
      return matchesTerm && matchesDate;
    });
  }

  getGroupedContacts() {
    interface GroupedContacts {
      [key: string]: { title: string, fecha: string, profesor: string }[];
    }

    const grouped: GroupedContacts = this.filteredContacts.reduce((groups, contact) => {
      const title = contact.title;
      if (!groups[title]) {groups[title] = [];}groups[title].push(contact);
      return groups;
    }, {} as GroupedContacts);
    
    return Object.entries(grouped);
  }
}
