import { Component } from '@angular/core';

interface Menu{
  icon:string;
  name:string; 
  redirecTo: string;
}

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {

  menu:Menu[]=[
    
    {
      icon:'home-outline',
      name:'Home',
      redirecTo: '/tabs/tab1'
    },
    {
      icon:'people-outline',
      name:'Asignatura',
      redirecTo: '/tabs/tab2'
    },
    {
      icon:'person-circle-outline',
      name:'Mi Perfil',
      redirecTo: '/tabs/tab3'
    },
    {
      icon:'qr-code-outline',
      name:'Qr',
      redirecTo: '/tabs/tab4'
    },
    {
      icon:'sparkles-outline',
      name:'Iniciar Sesión',
      redirecTo: '/comienzo'
    },
    {
      icon:'sparkles-outline',
      name:'Registro',
      redirecTo: '/registro'
    },

  ]

  constructor() {}
}



