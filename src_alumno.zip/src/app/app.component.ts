import { Component } from '@angular/core';
import { AuthserviceService } from './services/authservice.service';
import { Router } from '@angular/router';

interface Menu{
  icon:string;
  name:string; 
  redirecTo: string;
}

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  menu:Menu[]=[
    
    {
      icon: 'home-outline',
      name: 'Home',
      redirecTo: '/tabs/tab1'
    },
    {
      icon: 'people-outline',
      name: 'Asignatura',
      redirecTo: '/tabs/tab2'
    },
    {
      icon: 'person-circle-outline',
      name: 'Mi Perfil',
      redirecTo: '/tabs/tab3'
    },
    {
      icon: 'qr-code-outline',
      name: 'Qr',
      redirecTo: '/tabs/tab4'
    },
    
  ];

  constructor( private authService: AuthserviceService, 
               private router: Router
  ) {}


  onLogout() {
    this.authService.logout(); // Llama al método de cierre de sesión en tu servicio de autenticación
    this.router.navigate(['/comienzo']); // Redirige a la página de inicio de sesión
  }

  isMenuDisabled() {
    return !this.authService.IsLoggedIn(); // Deshabilitar si el usuario no está logueado
  }
}



