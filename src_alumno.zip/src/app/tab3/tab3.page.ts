import { Component } from '@angular/core';

@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss']
})
export class Tab3Page {
  isEditing: { [key: string]: boolean } = {};

  constructor() {}

  // Método para alternar entre editar y solo lectura
  toggleEdit(id: string) {
    this.isEditing[id] = !this.isEditing[id];
  }

  // Método para borrar el contenido del campo
  clearField(id: string) {
    const input = document.getElementById(id) as HTMLInputElement;
    if (input) {
      input.value = ''; // Limpiar el campo de entrada
      this.isEditing[id] = false; // Asegurar que vuelva a solo lectura
    }
  }

  // Método para verificar si el campo está en modo edición
  isFieldEditable(id: string): boolean {
    return this.isEditing[id];
  }

  // Método para actualizar el valor del campo
  updateField(id: string, event: Event) {
    const input = event.target as HTMLInputElement;
    const value = input.value;
    console.log(`Campo ${id} actualizado con valor: ${value}`);
    // Aquí puedes agregar lógica para almacenar el valor si es necesario
  }
}