import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApicrudService } from '../services/apicrud.service';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-actualizar',
  templateUrl: './actualizar.page.html',
  styleUrls: ['./actualizar.page.scss'],
})
export class ActualizarPage implements OnInit {

  asignatura:any;

  unAsignatura ={
    id: "",
    nombre: "",
    profesor: "",
    horario: ""
  };

  

  constructor(private activated: ActivatedRoute,
              private router: Router,
              private apicrud: ApicrudService,
              private alertcontroller: AlertController) {
                this.activated.queryParams.subscribe(param =>{
                  this.asignatura = JSON.parse(param['asignatura']);
                })
               }

  ngOnInit() {
    this.unAsignatura=this.asignatura;
  }

  updateAsignatura(){
    this.apicrud.putAsignatura(this.asignatura).subscribe();
    this.mensaje();
  }

  async mensaje(){
    const alert = await this.alertcontroller.create({
      header: 'Actualizando!',
      message: 'Sus Datos han sido Actualizado',
      buttons: [
        {
          text: 'OK',
          role: 'confirm',
          handler: () => {
            this.router.navigate(['/tabs/tab1']);
          },
        },
      ],
    });

    await alert.present();

  }

 }
  
