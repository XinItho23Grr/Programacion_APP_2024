//peticion,get,put,delete
export interface IAsignaturas{
    id: number;
    nombre: string;
    profesor:string;
    horario:string;
}

//peticion post
export interface Iasignatura{
    nombre: string;
    profesor:string;
    horario:string;

}
export interface IAlumno {
    id: number;
    nombre: string;
    email: string;
    rut: string;
  }


