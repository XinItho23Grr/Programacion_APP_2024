//peticion,get,put,delete
export interface IAlumnos{
    id: number;
    nombre: string;
    apellido:string;
    rut:string;
    email: string;
    password: string;
}

//peticion post
export interface IAlumno{
    nombre: string;
    apellido:string;
    rut:string;
    email: string;
    password: string;

}
