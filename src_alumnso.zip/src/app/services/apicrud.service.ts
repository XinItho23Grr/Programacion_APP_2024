import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { IAsignaturas, Iasignatura, IAlumno } from 'src/interfaces/IAsignatura';
import { UserNuevo } from 'src/interfaces/users';

@Injectable({
  providedIn: 'root'
})
export class ApicrudService {

  constructor(private httpclient: HttpClient) { }

  getAsignatura():Observable<IAsignaturas[]>{
    return this.httpclient.get<IAsignaturas[]>(`${environment.apiUrl}/asignatura`);
  }

  postAsignatura(newAsignatura: Iasignatura):Observable<Iasignatura>{
    return this.httpclient.post<Iasignatura>(`${environment.apiUrl}/asignaturas`,newAsignatura);
  }

  putAsignatura(asignatura:any):Observable<IAsignaturas>{
    return this.httpclient.put<IAsignaturas>(`${environment.apiUrl}/asignaturas/${asignatura.id}`,asignatura);

  }

  deleteAsignatura(asignatura:any):Observable<IAsignaturas>{
    return this.httpclient.delete<IAsignaturas>(`${environment.apiUrl}/asignaturas/${asignatura.id}`);
  }

  getAlumnos(): Observable<IAlumno[]> {
  return this.httpclient.get<IAlumno[]>(`${environment.apiUrl}/usuarios`);
  }


  //Usuario
  getUsers(): Observable<UserNuevo[]> {
    return this.httpclient.get<UserNuevo[]>(`${environment.apiUrl}/usuarios`);
  }

  postUser(newUser: UserNuevo): Observable<UserNuevo> {
    return this.httpclient.post<UserNuevo>(`${environment.apiUrl}/usuarios`, newUser);
  }

  putUsers(user: any): Observable<UserNuevo> {
    return this.httpclient.put<UserNuevo>(`${environment.apiUrl}/usuarios/${user.id}`, user);
  }

  deleteUser(user: any): Observable<UserNuevo> {
    return this.httpclient.delete<UserNuevo>(`${environment.apiUrl}/usuarios/${user.id}`);
  }
}
