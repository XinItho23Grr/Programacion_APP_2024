import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-tab5',
  templateUrl: './tab5.page.html',
  styleUrls: ['./tab5.page.scss'],
})
export class Tab5Page {

  imageSrc: string | ArrayBuffer | null = null;
  name: string = '';
  email: string = '';

  constructor( private navController: NavController ) { }

  onFileChange(event: any) {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        this.imageSrc = reader.result;
        // Si deseas almacenar la imagen en el almacenamiento local
        localStorage.setItem('photo', this.imageSrc as string);
      };
      reader.readAsDataURL(file);
    }
  }

  updateDisplayedName() {
    localStorage.setItem('name', this.name);
  }

  updateDisplayedEmail() {
    localStorage.setItem('email', this.email);
  }

  // Almacenar información
  ngOnInit() {
    this.imageSrc = localStorage.getItem('photo');
    this.name = localStorage.getItem('name') || '';
    this.email = localStorage.getItem('email') || '';
  }

  goBack() {
    this.navController.back();
  }

}
