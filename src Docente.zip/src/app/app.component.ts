import { Component } from '@angular/core';

interface Menu{
  icon:string;
  name:string; 
  redirecTo: string;
}

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {

  menu:Menu[]=[
    {
      icon:'sparkles-outline',
      name:'Iniciar Sesión',
      redirecTo: '/comienzo'
    },
    {
      icon:'home-outline',
      name:'Inicio',
      redirecTo: '/tabs/tab1'
    },
    {
      icon:'people-outline',
      name:'Clases',
      redirecTo: '/tabs/tab2'
    },
    {
      icon:'person-circle-outline',
      name:'Mi Perfil',
      redirecTo: '/tabs/tab3'
    },
    {
      icon:'sparkles-outline',
      name:'Registro Docente',
      redirecTo: '/registro'
    },

  ]

  constructor() {}
}



