import { Component } from '@angular/core';

@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss']
})
export class Tab3Page {

  imageSrc: string | ArrayBuffer | null = null; 

  constructor() {}

  onFileChange(event: any) {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        this.imageSrc = reader.result;
        // Si deseas almacenar la imagen en el almacenamiento local
        localStorage.setItem('photo', this.imageSrc as string);
      };
      reader.readAsDataURL(file);
    }
  }

  ngOnInit() {
    this.imageSrc = localStorage.getItem('photo');
  }

}
