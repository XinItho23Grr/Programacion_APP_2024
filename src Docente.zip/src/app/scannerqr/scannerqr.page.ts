import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-scannerqr',
  templateUrl: './scannerqr.page.html',
  styleUrls: ['./scannerqr.page.scss'],
})
export class ScannerqrPage {

  constructor( private navController: NavController) { }

  ngOnInit() {
  }

  goBack() {
    this.navController.back();
  }

}