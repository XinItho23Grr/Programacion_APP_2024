import { Component } from '@angular/core';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page {

  // Datos iniciales para las secciones y contactos
  allContacts = [
    { title: 'Sección 007', contacts: [
      { name: 'Jairo Echavarria', attendance: 85, nonattendance: '...' },
      { name: 'Pablo Avendaño', attendance: 82, nonattendance: 'Problemas medicos' },
      { name: 'Isaac Paz', attendance: 40, nonattendance: '...' }
    ]},
    { title: 'Sección 009', contacts: [
      { name: 'Itho Satochi', attendance: 75, nonattendance: '...' },
      { name: 'Benjamin Romero', attendance: 65, nonattendance: '...' },
      { name: 'Benjamin Ignacio', attendance: 90, nonattendance: '...' }
    ]}
  ];

  // Datos filtrados que se muestran en la interfaz
  filteredContacts = [...this.allContacts];

  // Información del contacto seleccionado
  selectedContact: { name: string, attendance: number, nonattendance: string } | null = null;

  constructor( private navController: NavController) {}

  ngOnInit() {
  }

  // Método para filtrar contactos según la búsqueda
  filterContacts(event: any) {
    const searchTerm = event.target.value.toLowerCase();
    this.filteredContacts = this.allContacts.map(section => {
      return {
        title: section.title,
        contacts: section.contacts.filter(contact => 
          contact.name.toLowerCase().includes(searchTerm)
        )
      };
    }).filter(section => section.contacts.length > 0);
  }

  // Método para manejar el clic en un contacto
  showAttendance(contact: { name: string, attendance: number, nonattendance: string }) {
    this.selectedContact = contact;
  }

  // Método para manejar el clic en una sección
  showSectionDetails(sectionTitle: string) {
    const section = this.allContacts.find(sec => sec.title === sectionTitle);
    if (section) {
      // Puedes realizar alguna acción aquí, como mostrar un modal con los detalles
      console.log('Detalles de la sección:', section);
    }
  }

  goToScannerQR() {
    // Redirigir a la página de scannerqr
    this.navController.navigateForward('/scannerqr');
  }
}
