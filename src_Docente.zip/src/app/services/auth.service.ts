import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private apiUrl = 'http://localhost:3000/';
  private usuarios: any[] = [];

  constructor(private http: HttpClient) {}

  register(correo: string, pass: string): void {
    this.usuarios.push({ correo, pass });
  }

  login(correo: string, pass: string): Observable<any> {
    const body = { correo, pass };
    return this.http.post(this.apiUrl, body);
  }
}