import { Component, OnInit } from '@angular/core';
import { NavController, AlertController } from '@ionic/angular';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-registro',
  templateUrl: './registro.page.html',
  styleUrls: ['./registro.page.scss'],
})
export class RegistroPage implements OnInit {
  registroForm: FormGroup;

  constructor(
    private alertController: AlertController,
    private navController: NavController,
    private formBuilder: FormBuilder,
    private authService: AuthService
  ) {
    // Inicializamos el FormGroup
    this.registroForm = this.formBuilder.group({
      rut: ['', [Validators.required]],
      nombre: ['', [Validators.required]],
      apellido: ['', [Validators.required]],
      correo: ['', [Validators.required, Validators.email]],
      pass: ['', [Validators.required, Validators.minLength(6)]],
    });
  }

  ngOnInit() {
    // Inicialización si es necesaria
  }

  async registro() {
    if (this.registroForm.valid) {
      this.authService.register(this.registroForm.value.correo, this.registroForm.value.pass);
  
      const alert = await this.alertController.create({
        header: 'Éxito',
        message: 'Registro realizado correctamente.',
        buttons: ['OK'],
      });
      
      await alert.present();
      await alert.onDidDismiss();
      this.navController.navigateForward('/comienzo');
    } else {
      const alert = await this.alertController.create({
        header: 'Error',
        message: 'Por favor, completa todos los campos correctamente.',
        buttons: ['OK'],
      });
      await alert.present();
    }
  }
}  