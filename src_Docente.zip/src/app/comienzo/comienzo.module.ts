import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ComienzoPageRoutingModule } from './comienzo-routing.module';

import { ComienzoPage } from './comienzo.page';

import { AuthService } from '../services/auth.service';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ComienzoPageRoutingModule,
  ],
  declarations: [ComienzoPage],
  providers: [AuthService]
})
export class ComienzoPageModule {}
