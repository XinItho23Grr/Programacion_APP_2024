import { Component, OnInit } from '@angular/core';
import { NavController, AlertController } from '@ionic/angular';
import { AuthService } from '../services/auth.service';
import { HttpErrorResponse } from '@angular/common/http'; // Importa HttpErrorResponse

@Component({
  selector: 'app-comienzo',
  templateUrl: './comienzo.page.html',
  styleUrls: ['./comienzo.page.scss'],
})
export class ComienzoPage implements OnInit {
  correo: string = '';;
  pass: string = '';;

  constructor(
    private navController: NavController,
    private alertController: AlertController,
    private authService: AuthService
  ) {}

  ngOnInit() {}

  async login() {
    if (this.correo && this.pass) {
      this.authService.login(this.correo, this.pass).subscribe(
        async (respuesta) => {
          if (respuesta) {
            const alert = await this.alertController.create({
              header: 'Éxito',
              message: 'Inicio de sesión exitoso.',
              buttons: ['OK'],
            });
            await alert.present();
            await alert.onDidDismiss();
            this.navController.navigateForward('/tabs/tab1');
          } else {
            const alert = await this.alertController.create({
              header: 'Error',
              message: 'Credenciales incorrectas. Intenta de nuevo.',
              buttons: ['OK'],
            });
            await alert.present();
          }
        },
        async (error) => {
          console.error('Error en la solicitud:', error);
          const alert = await this.alertController.create({
            header: 'Error',
            message: 'Hubo un problema al intentar iniciar sesión.',
            buttons: ['OK'],
          });
          await alert.present();
        }
      );
    } else {
      const alert = await this.alertController.create({
        header: 'Error',
        message: 'Por favor, completa todos los campos.',
        buttons: ['OK'],
      });
      await alert.present();
    }
  }  

  goToRegistro() {
    this.navController.navigateForward('/registro');
  }

  openUrl(url: string) {
    window.open(url, '_blank');
  }
}