import { Component } from '@angular/core';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss']
})
export class Tab3Page {

  imageSrc: string | ArrayBuffer | null = null;
  displayedName: string = '';
  displayedEmail: string = '';
  displayedAsignatura: string = '';

  constructor( private navController: NavController) {}

  ngOnInit() {
    this.imageSrc = localStorage.getItem('photo');
    this.displayedName = localStorage.getItem('name') || '';
    this.displayedEmail = localStorage.getItem('email') || '';
    this.displayedAsignatura = localStorage.getItem('asignatura') || '';
  }

  goToConfigurarPerfil() {
    // Redirigir a la página de configuración
    this.navController.navigateForward('/tab5');
  }

}
