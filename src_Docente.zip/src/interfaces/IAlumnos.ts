//peticion,get,put,delete
export interface IAlumnos{
    id: number;
    nombre: string;
    asistencia:number;
    inasistencia: string;
}

//peticion post
export interface IAlumno{
    id: number;
    nombre: string;
    asistencia:number;
    inasistencia: string;

}
